<?php
echo $_SERVER['HTTP_USER_AGENT'] . "\n\n";
//
//$browser = get_browser(null, true);
//echo json_encode($browser);
//foreach($_SERVER as $key => $value){
//    echo '$_SERVER["'.$key.'"] = '.$value."<br />";
//}
?>

