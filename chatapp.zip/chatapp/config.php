<?php
/**
 * DB configuration variables
 */
define("DB_HOST", 'localhost');
define("DB_USER", 'jook');
define("DB_PASSWORD", '47530213');
define("DB_DATABASE", 'ChatApp');
?>