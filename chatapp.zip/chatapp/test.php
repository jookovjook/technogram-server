<?php
include_once 'db_functions.php';

$db = new DB_Functions();

echo $db->getImageByLink("bWiAEklrV01NvNTwLKcOUfIQA4xVLJvLBE2anO8PQZGixBqWmrruHCL18N93d7w.jpg");