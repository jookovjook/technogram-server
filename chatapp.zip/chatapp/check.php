<?php
echo 1;